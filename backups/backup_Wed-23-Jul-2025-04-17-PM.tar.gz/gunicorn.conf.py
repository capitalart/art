# gunicorn.conf.py

bind = "0.0.0.0:7777"
workers = 4
timeout = 120
loglevel = "info"
