# Changelog

## [Unreleased]
- Standardised UI colour variables and button styles.
- Added keyboard accessible mockup carousel modal on edit listing page.
- Fixed locked gallery thumbnails by including main image data.
