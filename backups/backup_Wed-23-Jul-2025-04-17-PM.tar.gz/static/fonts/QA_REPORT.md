# QA Report: static/fonts
_Audit date: 2025-07-09 19:00 UTC_

| File | Purpose/Role | Status | Issues |
|------|--------------|--------|--------|
| static/fonts/Inter-Italic-VariableFont_opsz,wght.ttf | - | ❌ | Could not read file: 'utf-8' codec can't decode byte 0xb3 in position 16: invalid start byte |
| static/fonts/Inter-VariableFont_opsz,wght.ttf | - | ❌ | Could not read file: 'utf-8' codec can't decode byte 0xac in position 18: invalid start byte |
| static/fonts/Montserrat-Italic-VariableFont_wght.ttf | - | ❌ | Could not read file: 'utf-8' codec can't decode byte 0x80 in position 11: invalid start byte |
| static/fonts/Montserrat-VariableFont_wght.ttf | - | ❌ | Could not read file: 'utf-8' codec can't decode byte 0x80 in position 11: invalid start byte |

---
## Next Steps
- [ ] Review `static/fonts/Inter-Italic-VariableFont_opsz,wght.ttf`
- [ ] Review `static/fonts/Inter-VariableFont_opsz,wght.ttf`
- [ ] Review `static/fonts/Montserrat-Italic-VariableFont_wght.ttf`
- [ ] Review `static/fonts/Montserrat-VariableFont_wght.ttf`

